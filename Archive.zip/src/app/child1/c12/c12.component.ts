import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c12',
  templateUrl: './c12.component.html',
  styleUrls: ['./c12.component.scss']
})
export class C12Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
