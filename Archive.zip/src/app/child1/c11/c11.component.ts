import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c11',
  templateUrl: './c11.component.html',
  styleUrls: ['./c11.component.scss']
})
export class C11Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
