import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c13',
  templateUrl: './c13.component.html',
  styleUrls: ['./c13.component.scss']
})
export class C13Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
