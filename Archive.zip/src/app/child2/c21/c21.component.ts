import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c21',
  templateUrl: './c21.component.html',
  styleUrls: ['./c21.component.scss']
})
export class C21Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
