import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c23',
  templateUrl: './c23.component.html',
  styleUrls: ['./c23.component.scss']
})
export class C23Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
