import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-c22',
  templateUrl: './c22.component.html',
  styleUrls: ['./c22.component.scss']
})
export class C22Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
